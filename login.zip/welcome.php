<?php
session_start();
if (isset($_SESSION['uid'])) {
    $uid = $_SESSION['uid'];
    echo "Welcome, " . $uid . "!";
} else {
    echo 'Anonymous';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
</head>

<body>
    <!-- 網址：http://localhost/老師版/welcome.php -->
    <h1>成功登入</h1>
    <form action="logout.php" method="post">
        <button id="quit">登出</button>
        <input type="hidden" name="logout_redirect" value="logout.html">
    </form>
</body>

</html>
