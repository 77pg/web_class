<?php
session_start();
if (!$_SESSION['uid']) {
    header('location: login.php');
    die();
}
require('db.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 確認使用者已提交表單
    $uid = $_SESSION['uid'];
    $cname = $_POST['cname'];
    $pwd = $_POST['pwd'];
    $birthday = $_POST['birthday'];

    // 获取上传的文件信息
    $image = $_FILES['image']['tmp_name'];
    $image_data = '';

    if (!empty($image)) {
        $image_data = file_get_contents($image);
    }

    // 更新資料庫中的欄位值
    $sql = 'UPDATE userinfo SET cname = ?, pwd = ?, birthday = ?, image = ? WHERE uid = ?';
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param('sssss', $cname, $pwd, $birthday, $image_data, $uid);
    $stmt->send_long_data(3, $image_data);
    $stmt->execute();

    // 檢查更新是否成功
    if ($stmt->affected_rows > 0) {
        // 更新成功
        echo '<script>alert("資料修改成功！\n\n姓名：' . $cname . '\n密碼：' . $pwd . '\n生日：' . $birthday . '");
         setTimeout(function() { window.location.href = "welcome.php"; }, 2000);</script>';
    } else {
        // 更新失敗
        echo '<script>alert("修改資料時發生錯誤！");</script>';
    }

    $stmt->close();
}

// 取得使用者資料
$uid = $_SESSION['uid'];
$sql = 'SELECT * FROM userinfo WHERE uid = ?';
$stmt = $mysqli->prepare($sql);
$stmt->bind_param('s', $uid);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$cname = $row['cname'];
$pwd = $row['pwd'];
$birthday = $row['birthday'];

$image = $row['image'];
if ($image == null) {
    $image = file_get_contents(("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1zbW2LsUxp_IT0_O9-khcIY-6_BnL_pp_Wg&usqp=CAU"));
}
$mime_type = (new finfo(FILEINFO_MIME_TYPE))->buffer($image);
$image_base64 = base64_encode($image);
$src = "data:{$mime_type};base64,{$image_base64}";

$stmt->close();
$mysqli->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改使用者資料</title>
</head>

<body>
    <div>
        <button onclick="location.href='welcome.php'">返回</button>
    </div>

    <form action="" method="post" enctype="multipart/form-data">
        <h1>修改使用者資料</h1>
        <label for="cname">姓名：</label>
        <input type="text" name="cname" id="cname" value="<?= $cname ?>"><br><br>

        <label for="pwd">密碼：</label>
        <input type="password" name="pwd" id="pwd" value="<?= $pwd ?>"><br><br>

        <label for="birthday">生日：</label>
        <input type="text" name="birthday" id="birthday" value="<?= $birthday ?>"><br><br>

        <label for="image">圖片：</label>
        <input type="file" name="image" id="image">
        <img src="<?= $src ?>" width="200">

        <button type="submit">確認修改</button>
    </form>
</body>

</html>
